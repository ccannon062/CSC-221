# interest.py
# Caleb Cannon
# This program will take your initial principal, calculate your interest over a period of time, and return the final value.

def intro():
    print("Hello, welcome to the interest calculator!")
    print("This program will take your inital principal, calculate your interest over a period of time, and return the final sum")

def principal():
    principal = float(input("What is your initial principal amount (initial investment)? "))
    print()
    rate = float(input("What is the interest rate on your investment? "))
    print()
    compound = int(input("What is the compound frequency of your investment (Choose: 1, 2, 4, 12, 136) "))
    print()
    time = int(input("HOw many years do you intend to leave your investment for? "))
    print()
    return principal, rate, compound, time

def main():
    intro()
    p, r, n, t = principal()
    r = r / 100
    totalAmount = p * (1 + r / n) ** (n * t)
    totalInterest = totalAmount - p

    print("Your total balance will be: $",round(totalAmount, 2))
    print("The total amount of interest earned on the account over",t,"years is $",round(totalInterest, 2))

main() 
    
