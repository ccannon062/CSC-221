# changeovertime.py
# Caleb Cannon
# A program that calculates the average of burial permits over a seven year period.

def main():
    numYears = 7
    inputYear = input("Please input the year in which you are starting from: ")
    inputBurials = int(input("Please input the number of burials for the first year: "))
    grandTotal = 0
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    inputYear = input("Please input the second year: ")
    inputBurials = int(input("Please input the number of burials for the second year: "))
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    inputYear = input("Please input the third year: ")
    inputBurials = int(input("Please input the number of burials for the third year: "))
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    inputYear = input("Please input the fourth year: ")
    inputBurials = int(input("Please input the number of burials for the fourth year: "))
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    inputYear = input("Please input the fifth year: ")
    inputBurials = int(input("Please input the number of burials for the fifth year: "))
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    inputYear = input("Please input the sixth year: ")
    inputBurials = int(input("Please input the number of burials for the sixth year: "))
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    inputYear = input("Please input the seventh year: ")
    inputBurials = int(input("Please input the number of burials for the seventh year: "))
    grandTotal = grandTotal + inputBurials
    print("Year:",inputYear)
    print("Burials:",inputBurials)
    avgBurials = grandTotal / numYears
    print("Total years:",numYears)
    print("Average number of burials over",numYears,"years:",round(avgBurials, 1))


main()
